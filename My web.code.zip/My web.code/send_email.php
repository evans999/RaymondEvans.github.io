<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $firstName = $_POST['firstName'];
  $lastName = $_POST['lastName'];
  $email = $_POST['email'];
  $message = $_POST['message'];

  // Email recipient
  $to = "raymondevans683@email.com";

  // Email subject
  $subject = "Contact Form Submission";

  // Email headers
  $headers = "From: " . $firstName . " " . $lastName . " <" . $email . ">\r\n";
  $headers .= "Reply-To: " . $email . "\r\n";
  $headers .= "Content-Type: text/html\r\n";

  // Email body
  $body = "First Name: " . $firstName . "<br>";
  $body .= "Last Name: " . $lastName . "<br>";
  $body .= "Email: <a href='mailto:" . $email . "'>" . $email . "</a><br>";
  $body .= "Message: " . $message;

  // Send email
  if (mail($to, $subject, $body, $headers)) {
    echo "Thank you for your message. We'll get back to you soon!";
  } else {
    echo "Sorry, something went wrong. Please try again later.";
  }
}
?>